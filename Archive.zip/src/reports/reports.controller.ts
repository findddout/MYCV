import { Controller } from '@nestjs/common';

@Controller('reports')
export class ReportsController {}
