export class CatDTO {
  name: string;
  age: number;
  breed: string;
}
