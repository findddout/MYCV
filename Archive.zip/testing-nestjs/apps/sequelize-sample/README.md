<p align="center">
  <img src="./testCoverage.png"/>
</p>

# Sequelize Sample

As Nest now has a sequelize package, there's now a test example for it! Enjoy!.
