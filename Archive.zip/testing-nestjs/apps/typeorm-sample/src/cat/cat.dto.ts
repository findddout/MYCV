export interface CatDTO {
  id?: string;
  name?: string;
  breed?: string;
  age?: number;
}
