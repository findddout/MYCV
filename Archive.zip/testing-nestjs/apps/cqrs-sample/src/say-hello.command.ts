export class SayHelloCommand {
  constructor(public readonly name: string) {}
}
