export class SaidHelloEvent {
  constructor(public readonly name: string) {}
}
