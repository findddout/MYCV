export interface CatDTO {
  _id?: string;
  name?: string;
  breed?: string;
  age?: number;
}
