export interface Cat {
  age: number;
  name: string;
  breed: string;
  id: string;
}
